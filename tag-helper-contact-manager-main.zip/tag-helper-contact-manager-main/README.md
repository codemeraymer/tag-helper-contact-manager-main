# Tag Helper Contact Manager
This project contains a sample ASP.NET Core app. This app is an example of the article I produced for the Telerik Blog (telerik.com/blogs).

## Technologies used in this project:

- .NET 7
- ASP.NET Core
- JSON file as database
- Tag Helpers

To run this project locally you need to have the .NET 7 SDK installed.
